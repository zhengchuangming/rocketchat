Template.registerHelper('log', (...args) => {
	console.log.apply(console, args);
});
