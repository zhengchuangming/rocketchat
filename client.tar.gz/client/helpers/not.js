Template.registerHelper('not', (value) => !value);
