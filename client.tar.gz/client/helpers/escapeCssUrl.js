Template.registerHelper('escapeCssUrl', (url) => url.replace(/(['"])/g, '\\$1'));
