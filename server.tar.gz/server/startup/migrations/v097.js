RocketChat.Migrations.add({
	version: 97,
	up() {
		// Migration moved to 099.js to fix a bug
	},
});
