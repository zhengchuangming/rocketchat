RocketChat.Migrations.add({
	version: 86,
	up() {
		// Disabled this migration for it was not updating any user
	},
});
