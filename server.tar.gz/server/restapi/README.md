# Important Information

The REST API has moved to `/api/v1/${endpoint}`, please see the [Rocket.Chat Documentation](https://rocket.chat/docs/developer-guides/rest-api) for details on the current REST API. If a feature is currently missing, feel free to open a new pull request to add it. :heart:
