Meteor.methods({
	getServerInfo() {
		return RocketChat.Info;
	},
});
