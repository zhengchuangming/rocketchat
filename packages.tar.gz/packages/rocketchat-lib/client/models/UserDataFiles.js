RocketChat.models.UserDataFiles = new class extends RocketChat.models._Base {
	constructor() {
		super();
		this._initModel('userDataFiles');
	}
};
