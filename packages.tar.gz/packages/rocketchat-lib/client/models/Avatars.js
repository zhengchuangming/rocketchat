RocketChat.models.Avatars = new class extends RocketChat.models._Base {
	constructor() {
		super();
		this._initModel('avatars');
	}
};
