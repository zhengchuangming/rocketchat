# rocketchat:grant-github

An implementation of the GitHub OAuth flow.
