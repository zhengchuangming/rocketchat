this.ChatOAuthApps = new Mongo.Collection('rocketchat_oauth_apps');
