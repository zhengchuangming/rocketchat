RocketChat.models.OAuthApps = new class extends RocketChat.models._Base {
	constructor() {
		super('oauth_apps');
	}
};


// FIND
// findByRole: (role, options) ->
// 	query =
// 	roles: role

// 	return @find query, options

// CREATE
