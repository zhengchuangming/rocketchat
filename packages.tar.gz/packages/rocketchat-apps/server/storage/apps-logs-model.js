export class AppsLogsModel extends RocketChat.models._Base {
	constructor() {
		super('apps_logs');
	}
}
