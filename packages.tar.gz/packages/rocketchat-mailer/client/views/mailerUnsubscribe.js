Template.mailerUnsubscribe.onRendered(function() {
	return $('#initial-page-loading').remove();
});
