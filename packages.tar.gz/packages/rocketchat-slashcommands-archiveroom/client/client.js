RocketChat.slashCommands.add('archive', null, {
	description: 'Archive',
	params: '#channel',
});
