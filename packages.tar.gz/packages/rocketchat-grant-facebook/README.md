# rocketchat:grant-facebook

An implementation of the Facebook OAuth flow.
