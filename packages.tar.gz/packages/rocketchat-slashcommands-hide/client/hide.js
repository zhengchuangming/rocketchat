RocketChat.slashCommands.add('hide', undefined, {
	description: 'Hide_room',
	params: '#room',
});
