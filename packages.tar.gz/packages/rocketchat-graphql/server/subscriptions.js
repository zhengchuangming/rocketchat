import { PubSub } from 'graphql-subscriptions';

export const pubsub = new PubSub();
