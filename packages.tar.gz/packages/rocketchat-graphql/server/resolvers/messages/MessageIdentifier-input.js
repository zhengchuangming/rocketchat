import schema from '../../schemas/messages/MessageIdentifier-input.graphqls';

export {
	schema,
};
