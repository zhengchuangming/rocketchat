import schema from '../../schemas/messages/MessagesWithCursor-type.graphqls';

export {
	schema,
};
