import schema from '../../schemas/messages/Reaction-type.graphqls';

export {
	schema,
};
