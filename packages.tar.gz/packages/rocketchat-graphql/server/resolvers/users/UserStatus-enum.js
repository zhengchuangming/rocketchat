import schema from '../../schemas/users/UserStatus-enum.graphqls';

export {
	schema,
};
