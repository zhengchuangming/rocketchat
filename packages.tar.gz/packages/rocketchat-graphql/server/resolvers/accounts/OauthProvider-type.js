import schema from '../../schemas/accounts/OauthProvider-type.graphqls';

export {
	schema,
};
