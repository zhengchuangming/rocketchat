export const roomPublicFields = {
	t: 1,
	name: 1,
	description: 1,
	announcement: 1,
	topic: 1,
	usernames: 1,
	msgs: 1,
	ro: 1,
	u: 1,
	archived: 1,
};
