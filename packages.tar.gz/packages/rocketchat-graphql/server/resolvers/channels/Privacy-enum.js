import schema from '../../schemas/channels/Privacy-enum.graphqls';

export {
	schema,
};
