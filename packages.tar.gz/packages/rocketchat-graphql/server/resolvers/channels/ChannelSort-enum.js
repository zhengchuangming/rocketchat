import schema from '../../schemas/channels/ChannelSort-enum.graphqls';

export {
	schema,
};
