import schema from '../../schemas/channels/ChannelFilter-input.graphqls';

export {
	schema,
};
