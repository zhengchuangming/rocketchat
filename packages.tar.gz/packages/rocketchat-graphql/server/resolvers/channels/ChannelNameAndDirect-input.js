import schema from '../../schemas/channels/ChannelNameAndDirect-input.graphqls';

export {
	schema,
};
