RocketChat.slashCommands.add('unarchive', null, {
	description: 'Unarchive',
	params: '#channel',
});
